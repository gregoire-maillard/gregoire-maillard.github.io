import sys, io
P = sys.argv[1]
src = open(P, encoding="utf-8").read()
orig = src
def rep(old, new, count=1):
    global src
    n = src.count(old)
    if n != count: sys.exit("anchor found %d times, expected %d: %r" % (n, count, old[:90]))
    src = src.replace(old, new)
ENTRIES = open(sys.argv[2], encoding="utf-8").read()
# 1. header comment
rep("""      // ── characters (TK-BUILD-2, TM-PROJECT.md 3): one per level, drawn in the style of the Turkish course's. The A1 foal walks
      // with the learner from the start; certifying a level brings the next level's character. The greeting above today's card
      // is the character picked in My Profile (kept in this browser only, outside the progress and its export), or else the
      // character of the level being worked on. It says a short Turkmen line first, then a word of English. ──""",
"""      // ── characters (TK-BUILD-2, nine since TK-CHARS; TM-PROJECT.md 3), drawn in the style of the Turkish course's. The
      // Akhal-Teke foal walks with the learner from the start; certifying A1, A2 or B1 brings that level's character (`level`),
      // and five achievements bring one each (`ach`). The greeting above today's card is the character picked in My Profile
      // (kept in this browser only, outside the progress and its export), or else the last level character met, or the foal.
      // It says a short Turkmen line first, then a word of English. `tk` is the animal's Turkmen name (AI-written, for the
      // native review); `hue` is the level colour of the greeting's bubble. ──""")
# 2. foal entry
rep('{ id: "a1", cefr: "A1", name: "Akhal\\u2011Teke foal",', '{ id: "a1", tag: "Start", hue: "a1", tk: "Taý", name: "Akhal\\u2011Teke foal",')
# 3. replace the A2 and B1 entries
i = src.index('        { id: "a2", cefr: "A2"'); j = src.index("\n      ];", i)
if j - i > 8000: sys.exit("A2/B1 block unexpectedly long")
src = src[:i] + ENTRIES + src[j:]
# 4. helpers instead of prevCefr
rep("""      function prevCefr(c) { var i = CHARS.indexOf(c); return i > 0 ? CHARS[i - 1].cefr : ""; }\n""",
"""      // The achievements by id (worked out from the progress, as in My Profile's list), for the characters they bring.
      function achById() {
        var m = {};
        try { T.progress.achievements(st.index, store.course(), store.cards(), store.settings(), Date.now()).forEach(function (a) { m[a.id] = a; }); } catch (e) {}
        return m;
      }
      // How to meet a character not met yet, in plain text.
      function howToMeet(c, ach) {
        var a = c.ach && ach[c.ach];
        if (c.level) return "Certify " + c.level.toUpperCase() + " to meet the " + c.name.toLowerCase() + ": finish every unit of the level";
        return "Earn " + (a ? a.en + " (" + a.text.charAt(0).toLowerCase() + a.text.slice(1) + ")" : "an achievement") + " to meet the " + c.name.toLowerCase();
      }
""")
# 5. charsMet and currentChar
rep("""      // The characters the learner has met: the A1 foal from the start, then the next level's with each level certified.
      function charsMet(s) {
        var met = { a1: true };
        s.levels.forEach(function (l, i) { if (l.certified && s.levels[i + 1]) met[s.levels[i + 1].id] = true; });
        return met;
      }
      function currentChar(s) {
        var met = charsMet(s), mine = storedChar(), w = s.working || s.certified;
        if (mine && met[mine] && charOf(mine)) return mine;
        return w && met[w.id] && charOf(w.id) ? w.id : "a1";
      }""",
"""      // The characters the learner has met: the foal from the start, a level's character once the level is certified, an
      // achievement's once it is earned. Nothing new is stored, so they follow the learner with an exported file.
      function charsMet(s, ach) {
        var met = { a1: true }, cert = {};
        ach = ach || achById();
        s.levels.forEach(function (l) { if (l.certified) cert[l.id] = true; });
        CHARS.forEach(function (c) { if (c.level ? cert[c.level] : c.ach && ach[c.ach] && ach[c.ach].done) met[c.id] = true; });
        return met;
      }
      function currentChar(s, ach) {
        var met = charsMet(s, ach), mine = storedChar(), lv = CHARS.filter(function (c) { return c.level && met[c.id]; }).pop();
        if (mine && met[mine] && charOf(mine)) return mine;
        return lv ? lv.id : "a1";
      }""")
# 6. greeting colour
rep("""'" id="hello" href="#profile" data-lvl="' + id + '"''', """'" id="hello" href="#profile" data-lvl="' + c.hue + '"''')
# 7. My Profile
rep("""      // ── characters in My Profile: the three, met or not yet; the one picked greets you on the course page ──
      function renderChars(s) {
        var el = $("pf-chars"), met = charsMet(s), cur = currentChar(s), mine = storedChar(), n = Object.keys(met).length, c0 = charOf(cur);
        var note = pf.charMsg || "<b>" + esc(c0.name) + "</b>: " + esc(c0.blurb) + ".";""",
"""      // ── characters in My Profile: the nine, met or not yet; the one picked greets you on the course page ──
      function renderChars(s) {
        var ach = achById(), el = $("pf-chars"), met = charsMet(s, ach), cur = currentChar(s, ach), mine = storedChar(), n = Object.keys(met).length, c0 = charOf(cur);
        var note = pf.charMsg || "<b>" + esc(c0.name) + '</b> (<i lang="tk">' + esc(c0.tk) + "</i>): " + esc(c0.blurb) + ".";""")
rep("""            var ok = !!met[c.id], on = ok && c.id === cur;""",
"""            var ok = !!met[c.id], on = ok && c.id === cur, how = ok ? "" : howToMeet(c, ach), a = c.ach && ach[c.ach];""")
rep("""' title="' + esc(ok ? c.name + ": " + c.blurb : "Certify " + prevCefr(c) + " to meet the " + c.name.toLowerCase()) + '">' + charSvg(c.id, 52) +
              '<span class="nm">' + esc(c.name) + '</span><span class="lv">' + c.cefr + "</span>" +""",
"""' title="' + esc(ok ? c.name + ": " + c.blurb : how) + '">' + charSvg(c.id, 52) +
              '<span class="nm">' + esc(c.name) + '</span><span class="lv">' + esc(c.tag || (a ? a.en : "")) + "</span>" +""")
rep("""'<span class="sr">' + (ok ? (on ? ", greets you on the course page" : "") : ", not met yet: certify " + prevCefr(c) + " to meet it") + "</span></button>";""",
"""'<span class="sr">' + (ok ? (on ? ", greets you on the course page" : "") : ", not met yet: " + esc(how.charAt(0).toLowerCase() + how.slice(1))) + "</span></button>";""")
rep("""        if (b.getAttribute("aria-disabled") === "true") { pf.charMsg = "Certify <b>" + prevCefr(c) + "</b> to meet the " + esc(c.name.toLowerCase()) + ": finish every unit of the level."; renderProfile(); return; }""",
"""        if (b.getAttribute("aria-disabled") === "true") { pf.charMsg = esc(howToMeet(c, achById())) + "."; renderProfile(); return; }""")
if "prevCefr" in src or ".cefr + \"</span>" in src: sys.exit("leftover prevCefr")
open(P, "w", encoding="utf-8").write(src)
print("patched", len(orig), "->", len(src))
